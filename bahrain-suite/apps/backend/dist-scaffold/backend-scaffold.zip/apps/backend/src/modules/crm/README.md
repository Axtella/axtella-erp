CRM domain scaffold root.
