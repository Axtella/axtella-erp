Hotel domain scaffold root.
