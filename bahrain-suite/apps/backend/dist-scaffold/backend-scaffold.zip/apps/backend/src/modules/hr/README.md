HR domain scaffold root.
