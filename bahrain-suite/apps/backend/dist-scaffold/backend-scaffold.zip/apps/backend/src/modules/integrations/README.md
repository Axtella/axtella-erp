Integrations domain scaffold root.
