Accounting domain scaffold root.
