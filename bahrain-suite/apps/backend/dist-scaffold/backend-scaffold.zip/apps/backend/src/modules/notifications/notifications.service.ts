import { Injectable } from '@nestjs/common';

@Injectable()
export class NotificationsService {
  findAll() {
    return { module: 'notifications', items: [] };
  }
}
