import { Injectable } from '@nestjs/common';

@Injectable()
export class AttendanceService {
  findAll() {
    return { module: 'attendance', items: [] };
  }
}
