import { Controller, Get } from '@nestjs/common';
import { EmployeesService } from './employees.service';

@Controller('hr/employees')
export class EmployeesController {
  constructor(private readonly service: EmployeesService) {}

  @Get()
  findAll() {
    return this.service.findAll();
  }
}
