import { Injectable } from '@nestjs/common';

@Injectable()
export class ActivitiesService {
  findAll() {
    return { module: 'activities', items: [] };
  }
}
